nextplay = 1 if 2==  2 else 3
print(nextplay)